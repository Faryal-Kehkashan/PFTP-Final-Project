var btn1 = document.getElementById('btn1');
var btn2 = document.getElementById('btn2');

function login(){
    var login_form = document.getElementById("login_form");
    login_form.style.display = "grid";
}
function signup(){
    var signup_form = document.getElementById("signup_form");
    signup_form.style.display = "grid";
}